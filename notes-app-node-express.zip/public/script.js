let quill = new Quill("#editor", {
  theme: "snow",
  modules: { toolbar: [["bold", "italic"], [{ list: "bullet" }]] }
});

let currentFolder = null;
let folders = [];
let notes = {};

window.onload = () => {
  loadNotesFromServer();
};

function loadFoldersUI() {
  const list = document.getElementById("folder-list");
  list.innerHTML = "";
  folders.forEach(folder => {
    const li = document.createElement("li");
    li.textContent = folder.name;
    li.onclick = () => {
      currentFolder = folder.id;
      loadNote();
      loadFoldersUI();
    };
    li.className = folder.id === currentFolder ? "active" : "";
    list.appendChild(li);
  });
}

function addFolder() {
  const name = prompt("Enter folder name:");
  const id = Date.now().toString();
  folders.push({ id, name });
  currentFolder = id;
  loadFoldersUI();
}

function saveNote() {
  if (!currentFolder) return alert("No folder selected.");
  const title = document.getElementById("note-title").value;
  const content = quill.root.innerHTML;
  notes[currentFolder] = { title, content };
  alert("Note saved.");
}

function loadNote() {
  const note = notes[currentFolder];
  if (note) {
    document.getElementById("note-title").value = note.title;
    quill.root.innerHTML = note.content;
  } else {
    document.getElementById("note-title").value = "";
    quill.root.innerHTML = "";
  }
}

function deleteNote() {
  if (notes[currentFolder]) {
    delete notes[currentFolder];
    alert("Note deleted.");
    loadNote();
  }
}

function loadNotesFromServer() {
  fetch("/api/load-notes")
    .then(res => res.text())
    .then(csv => {
      folders = [];
      notes = {};
      const rows = csv.trim().split("\n");
      const header = rows[0].split(",");
      rows.slice(1).forEach((line, i) => {
        const [folder, title, ...contentParts] = line.split(",");
        const content = contentParts.join(",").replace(/^"|"$/g, "");
        let folderEntry = folders.find(f => f.name === folder);
        if (!folderEntry) {
          folderEntry = { id: Date.now().toString() + i, name: folder };
          folders.push(folderEntry);
        }
        notes[folderEntry.id] = { title, content };
      });
      currentFolder = folders[0]?.id || null;
      loadFoldersUI();
      loadNote();
    });
}

function saveNotesToServer() {
  let csv = "Folder,Title,Content\n";
  folders.forEach(f => {
    const note = notes[f.id];
    if (note) {
      csv += \`"\${f.name}","\${note.title}","\${note.content.replace(/"/g, '""')}"\n\`;
    }
  });
  fetch("/api/save-notes", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ csv })
  }).then(() => alert("Saved to server."));
}