const express = require("express");
const fs = require("fs");
const path = require("path");
const cors = require("cors");

const app = express();
const PORT = 3000;
const CSV_PATH = path.join(__dirname, "notes.csv");

app.use(cors());
app.use(express.json({ limit: "5mb" }));

// Serve frontend files
app.use(express.static(path.join(__dirname, "public")));

// Load notes from notes.csv
app.get("/api/load-notes", (req, res) => {
  fs.readFile(CSV_PATH, "utf8", (err, data) => {
    if (err) return res.status(500).json({ error: "Failed to read CSV." });
    res.type("text/csv").send(data);
  });
});

// Save notes to notes.csv
app.post("/api/save-notes", (req, res) => {
  const csvData = req.body.csv;
  fs.writeFile(CSV_PATH, csvData, "utf8", err => {
    if (err) return res.status(500).json({ error: "Failed to write CSV." });
    res.json({ success: true });
  });
});

app.listen(PORT, () => {
  console.log("Server running on http://localhost:" + PORT);
});
