let quill;
let currentFolder = null;

window.onload = () => {
  quill = new Quill("#editor", {
    theme: "snow",
    modules: {
      toolbar: [
        ["bold", "italic"],
        [{ list: "bullet" }],
        [{ 'font': [] }],
        [{ 'size': ['small', false, 'large', 'huge'] }],
        [{ 'color': [] }]
      ]
    }
  });

  currentFolder = localStorage.getItem("currentFolder");
  loadFolders();
  if (currentFolder) loadNote();
  else clearEditor();
};

function loadFolders() {
  const folders = JSON.parse(localStorage.getItem("folders") || "[]");
  const list = document.getElementById("folder-list");
  list.innerHTML = "";
  folders.forEach(folder => {
    const li = document.createElement("li");
    li.innerHTML = \`
      <span class="folder-name \${folder.id === currentFolder ? "active" : ""}">\${folder.name}</span>
      <span class="actions">
        <button onclick="renameFolder('\${folder.id}')">🖉</button>
        <button onclick="deleteFolder('\${folder.id}')">🗑</button>
      </span>
    \`;
    li.querySelector(".folder-name").onclick = () => {
      currentFolder = folder.id;
      localStorage.setItem("currentFolder", currentFolder);
      loadFolders();
      loadNote();
    };
    list.appendChild(li);
  });
}

function addFolder() {
  const name = prompt("Enter folder name:");
  if (!name) return;
  const folders = JSON.parse(localStorage.getItem("folders") || "[]");
  const id = Date.now().toString();
  folders.push({ id, name });
  localStorage.setItem("folders", JSON.stringify(folders));
  currentFolder = id;
  localStorage.setItem("currentFolder", currentFolder);
  loadFolders();
  clearEditor();
}

function renameFolder(id) {
  const folders = JSON.parse(localStorage.getItem("folders") || "[]");
  const folder = folders.find(f => f.id === id);
  const newName = prompt("Enter new folder name:", folder.name);
  if (newName) {
    folder.name = newName;
    localStorage.setItem("folders", JSON.stringify(folders));
    loadFolders();
  }
}

function deleteFolder(id) {
  if (!confirm("Delete this folder and its note?")) return;
  let folders = JSON.parse(localStorage.getItem("folders") || "[]");
  folders = folders.filter(f => f.id !== id);
  localStorage.setItem("folders", JSON.stringify(folders));

  const notes = JSON.parse(localStorage.getItem("notes") || "{}");
  delete notes[id];
  localStorage.setItem("notes", JSON.stringify(notes));

  if (currentFolder === id) {
    currentFolder = null;
    localStorage.removeItem("currentFolder");
    clearEditor();
  }
  loadFolders();
}

function saveNote() {
  if (!currentFolder) {
    alert("Please select or create a folder first.");
    return;
  }
  const title = document.getElementById("note-title").value;
  const content = quill.root.innerHTML;
  let notes = JSON.parse(localStorage.getItem("notes") || "{}");
  notes[currentFolder] = { title, content };
  localStorage.setItem("notes", JSON.stringify(notes));
  alert("Note saved!");
}

function loadNote() {
  const notes = JSON.parse(localStorage.getItem("notes") || "{}");
  const note = notes[currentFolder];
  if (note) {
    document.getElementById("note-title").value = note.title || "";
    quill.root.innerHTML = note.content || "";
  } else {
    clearEditor();
  }
}

function deleteNote() {
  if (!currentFolder) return;
  const notes = JSON.parse(localStorage.getItem("notes") || "{}");
  delete notes[currentFolder];
  localStorage.setItem("notes", JSON.stringify(notes));
  alert("Note deleted!");
  clearEditor();
}

function clearEditor() {
  document.getElementById("note-title").value = "";
  if (quill) quill.root.innerHTML = "";
}

function exportCSV() {
  const notes = JSON.parse(localStorage.getItem("notes") || "{}");
  const folders = JSON.parse(localStorage.getItem("folders") || "[]");
  let csv = "Folder,Title,Content\n";
  folders.forEach(f => {
    const note = notes[f.id];
    if (note) {
      const content = note.content.replace(/"/g, '""').replace(/\n/g, " ");
      const title = note.title.replace(/"/g, '""');
      csv += \`"\${f.name}","\${title}","\${content}"\n\`;
    }
  });
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "notes.csv";
  a.click();
}

function exportExcel() {
  const notes = JSON.parse(localStorage.getItem("notes") || "{}");
  const folders = JSON.parse(localStorage.getItem("folders") || "[]");
  const data = folders.map(f => {
    const note = notes[f.id] || {};
    return {
      "Folder": f.name,
      "Title": note.title || "",
      "Content (HTML)": note.content || ""
    };
  });
  const ws = XLSX.utils.json_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Notes");
  XLSX.writeFile(wb, "notes.xlsx");
}
